from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from app.services.yahoo import get_stock_summary  # adjust if needed

templates = Jinja2Templates(directory="app/templates")

router = APIRouter()

@router.get("/{ticker}", response_class=HTMLResponse)
async def get_stock(request: Request, ticker: str):
    stock_data = get_stock_summary(ticker)
    return templates.TemplateResponse("partials/stock_card.html", {
        "request": request,
        "ticker": ticker.upper(),
        "stock": stock_data
    })

@router.get("/search", response_class=HTMLResponse)
async def search_stock(request: Request, ticker: str):
    stock_data = get_stock_summary(ticker)
    return templates.TemplateResponse("partials/stock_card.html", {
        "request": request,
        "ticker": ticker.upper(),
        "stock": stock_data
    })

@router.get("/", response_class=HTMLResponse)
async def homepage(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
